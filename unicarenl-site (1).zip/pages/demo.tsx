export default function Demo() {
  return (
    <main className="p-8">
      <h1 className="text-3xl font-bold">Demo aanvraag</h1>
      <p className="mt-4">Hier komt het formulier voor demo-aanvraag.</p>
    </main>
  );
}
