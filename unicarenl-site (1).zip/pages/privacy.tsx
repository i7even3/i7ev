export default function Privacy() {
  return (
    <main className="p-8">
      <h1 className="text-3xl font-bold">Privacybeleid</h1>
      <p className="mt-4">Wij respecteren uw privacy en verwerken uw gegevens zorgvuldig.</p>
    </main>
  );
}
